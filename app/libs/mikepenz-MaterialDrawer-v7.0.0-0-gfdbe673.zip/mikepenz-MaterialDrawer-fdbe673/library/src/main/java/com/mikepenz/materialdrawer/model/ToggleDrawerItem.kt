package com.mikepenz.materialdrawer.model

/**
 * Created by mikepenz on 03.02.15.
 */
open class ToggleDrawerItem : AbstractToggleableDrawerItem<ToggleDrawerItem>()
